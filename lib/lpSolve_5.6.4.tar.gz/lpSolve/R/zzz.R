# .First.lib <- function(libname, pkgname) {
# library.dynam ("lpSolve", pkgname, libname)
# }
