.First.lib <- function(libname,pkgname,...) {
cat("Welcome to compositions, a package for compositional data analysis.\n")
cat("\n");
cat("Get help with \"? compositions\"")
cat("\n")
}
